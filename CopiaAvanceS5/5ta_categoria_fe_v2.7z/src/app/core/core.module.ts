import { NgModule } from "@angular/core";
import { AuthService } from "../public/login/auth.service";


@NgModule({
    imports: [],
    declarations: [],
    exports: [],
    providers: [AuthService]
})

export class CoreModule {
    constructor() {}
}
