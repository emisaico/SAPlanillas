export interface Pageable{
    page:number,
    size:number,
    orderParameter:string,
    typeOrder:string
}