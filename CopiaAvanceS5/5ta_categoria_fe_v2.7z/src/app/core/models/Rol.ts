export interface Rol{
    id_rol:number,
    tipo_rol:string
  }